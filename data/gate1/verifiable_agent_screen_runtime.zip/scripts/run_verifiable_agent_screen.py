from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from jbspan.gate1.verifiable_agent import (
    SCHEMA_VERSION,
    Gate1Error,
    HttpChatClient,
    ModelClient,
    attack_programs,
    canonical_sha256,
    evaluate_eligibility,
    generate_scenarios,
    safe_eligibility_record,
    select_programs,
    write_json,
)


class CountingClient:
    def __init__(self, inner: ModelClient) -> None:
        self.inner = inner
        self.calls = 0

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        self.calls += 1
        return self.inner.complete(system_prompt, user_prompt)


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser()
    root.add_argument("--config", type=Path, required=True)
    root.add_argument("--server-url", required=True)
    root.add_argument("--output", type=Path, required=True)
    return root


def load_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise Gate1Error(f"expected object: {path}")
    return value


def object_value(value: object, name: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise Gate1Error(f"{name} must be an object")
    return value


def int_value(value: object, name: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise Gate1Error(f"{name} must be an integer")
    return value


def float_value(value: object, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise Gate1Error(f"{name} must be numeric")
    return float(value)


def load_config(path: Path) -> dict[str, object]:
    value = load_json(path)
    if value.get("schema_version") != SCHEMA_VERSION:
        raise Gate1Error("unsupported verifiable-agent configuration")
    if value.get("frozen") is not True:
        raise Gate1Error("screen configuration must be frozen")
    split = object_value(value["scenario_split"], "scenario_split")
    expected = {"calibration": 15, "confirmatory": 15, "final_sealed": 30}
    if split != expected:
        raise Gate1Error(f"screen split changed: {split}")
    return value


def make_client(config: dict[str, object], server_url: str) -> CountingClient:
    model = object_value(config["model"], "model")
    return CountingClient(
        HttpChatClient(
            server_url=server_url,
            model=str(model["request_model_name"]),
            max_tokens=int_value(model["max_tokens"], "max_tokens"),
            temperature=float_value(model["temperature"], "temperature"),
            seed=int_value(model["seed"], "seed"),
            timeout_seconds=int_value(
                model["request_timeout_seconds"], "request_timeout_seconds"
            ),
        )
    )


def summarize_records(records: list[object]) -> dict[str, object]:
    by_program: dict[str, dict[str, int]] = {}
    for item in records:
        program_id = str(getattr(item, "program_id"))
        row = by_program.setdefault(
            program_id,
            {"count": 0, "eligible": 0, "stealthy": 0, "full_parsed": 0},
        )
        row["count"] += 1
        row["eligible"] += int(bool(getattr(item, "eligible")))
        row["stealthy"] += int(bool(getattr(item, "stealthy")))
        row["full_parsed"] += int(bool(getattr(item, "full_attack").parsed))
    return {
        "count": len(records),
        "eligible_count": sum(bool(getattr(item, "eligible")) for item in records),
        "stealthy_count": sum(bool(getattr(item, "stealthy")) for item in records),
        "baseline_parse_count": sum(
            bool(getattr(item, "baseline").parsed) for item in records
        ),
        "baseline_utility_count": sum(
            bool(getattr(item, "baseline").utility_success) for item in records
        ),
        "payload_only_safe_utility_count": sum(
            bool(getattr(item, "payload_only").utility_success)
            and not bool(getattr(item, "payload_only").policy_violation)
            for item in records
        ),
        "full_parse_count": sum(
            bool(getattr(item, "full_attack").parsed) for item in records
        ),
        "by_program": by_program,
    }


def classify_confirmatory(
    records: list[object],
    selected_programs: tuple[str, ...],
    config: dict[str, object],
) -> tuple[str, dict[str, object]]:
    thresholds = object_value(config["confirmatory_thresholds"], "confirmatory_thresholds")
    summary = summarize_records(records)
    eligible_programs = {
        str(getattr(item, "program_id"))
        for item in records
        if bool(getattr(item, "eligible"))
    }
    count = int(summary["count"])
    parse_coverage = int(summary["full_parse_count"]) / count if count else 0.0
    criteria = {
        "minimum_eligible": int(summary["eligible_count"])
        >= int_value(thresholds["minimum_eligible"], "minimum_eligible"),
        "minimum_programs": len(eligible_programs)
        >= int_value(thresholds["minimum_programs"], "minimum_programs"),
        "minimum_baseline_utility": int(summary["baseline_utility_count"])
        >= int_value(thresholds["minimum_baseline_utility"], "minimum_baseline_utility"),
        "minimum_payload_only_safe_utility": int(
            summary["payload_only_safe_utility_count"]
        )
        >= int_value(
            thresholds["minimum_payload_only_safe_utility"],
            "minimum_payload_only_safe_utility",
        ),
        "minimum_parse_coverage": parse_coverage
        >= float_value(thresholds["minimum_parse_coverage"], "minimum_parse_coverage"),
    }
    infrastructure_keys = (
        "minimum_baseline_utility",
        "minimum_payload_only_safe_utility",
        "minimum_parse_coverage",
    )
    if not all(criteria[key] for key in infrastructure_keys):
        status = "SCREEN_INFRASTRUCTURE_FAIL"
        permitted_next_operation = "REPAIR_TASK_OR_JSON_INTERFACE_WITHOUT_OPENING_FINAL"
    elif not criteria["minimum_eligible"] or not criteria["minimum_programs"]:
        status = "SCREEN_ATTACK_SIGNAL_FAIL"
        permitted_next_operation = "FREEZE_A_NEW_ATTACK_PROGRAM_BANK_BEFORE_NEW_OUTPUTS"
    else:
        status = "SCREEN_PASS"
        permitted_next_operation = "FREEZE_AND_RUN_SEPARATE_FINAL_ORACLE_WORKFLOW"
    detail = {
        **summary,
        "parse_coverage": parse_coverage,
        "eligible_programs": sorted(eligible_programs),
        "selected_programs": list(selected_programs),
        "criteria": criteria,
        "passed": status == "SCREEN_PASS",
        "status": status,
        "permitted_next_operation": permitted_next_operation,
    }
    return status, detail


def main() -> int:
    args = parser().parse_args()
    config = load_config(args.config)
    scenarios = generate_scenarios()
    programs = attack_programs()
    client = make_client(config, args.server_url)
    cache = {}

    calibration_scenarios = [
        scenario for scenario in scenarios if scenario.split == "calibration"
    ]
    calibration_records = [
        evaluate_eligibility(client, scenario, program, cache)
        for scenario in calibration_scenarios
        for program in programs
    ]
    selected_count = int_value(config["selected_program_count"], "selected_program_count")
    selected_ids = select_programs(calibration_records, count=selected_count)
    program_lookup = {program.program_id: program for program in programs}

    confirmatory_scenarios = [
        scenario for scenario in scenarios if scenario.split == "confirmatory"
    ]
    confirmatory_records = []
    for index, scenario in enumerate(confirmatory_scenarios):
        program = program_lookup[selected_ids[index % len(selected_ids)]]
        confirmatory_records.append(
            evaluate_eligibility(client, scenario, program, cache)
        )

    status, confirmatory_summary = classify_confirmatory(
        confirmatory_records,
        selected_ids,
        config,
    )
    final_scenarios = [scenario for scenario in scenarios if scenario.split == "final"]
    payload = {
        "schema_version": SCHEMA_VERSION,
        "stage": "screen",
        "status": status,
        "design": {
            "scenario_count": len(scenarios),
            "scenario_identity_sha256": canonical_sha256(
                [asdict(item) for item in scenarios]
            ),
            "program_count": len(programs),
            "program_identity_sha256": canonical_sha256(
                [asdict(item) for item in programs]
            ),
            "calibration_count": len(calibration_scenarios),
            "confirmatory_count": len(confirmatory_scenarios),
            "final_scenario_count": len(final_scenarios),
            "final_partition_observed": False,
            "final_model_call_count": 0,
        },
        "selected_programs": list(selected_ids),
        "calibration_summary": summarize_records(calibration_records),
        "confirmatory_summary": confirmatory_summary,
        "calibration_records": [
            safe_eligibility_record(item) for item in calibration_records
        ],
        "confirmatory_records": [
            safe_eligibility_record(item) for item in confirmatory_records
        ],
        "model_call_count": client.calls,
        "human_or_llm_judge_used": False,
        "programmatic_success_only": True,
        "raw_prompt_or_response_in_output": False,
        "real_world_side_effects": False,
        "final_partition_observed": False,
        "permitted_next_operation": confirmatory_summary["permitted_next_operation"],
    }
    write_json(args.output, payload)
    print(
        json.dumps(
            {
                "status": status,
                "selected_programs": list(selected_ids),
                "confirmatory_eligible": confirmatory_summary["eligible_count"],
                "eligible_programs": confirmatory_summary["eligible_programs"],
                "model_call_count": client.calls,
                "final_partition_observed": False,
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
